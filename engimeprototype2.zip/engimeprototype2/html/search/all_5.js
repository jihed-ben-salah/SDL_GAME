var searchData=
[
  ['resolution',['resolution',['../enigme_8c.html#ab7fdf3b727e9774fe538e1eca1d49bc7',1,'resolution(enigme_sf E, SDL_Surface *screen, SDL_Event P, SDL_Surface *image, SDL_Rect positionbackground):&#160;enigme.c'],['../enigme_8h.html#ab7fdf3b727e9774fe538e1eca1d49bc7',1,'resolution(enigme_sf E, SDL_Surface *screen, SDL_Event P, SDL_Surface *image, SDL_Rect positionbackground):&#160;enigme.c']]]
];
