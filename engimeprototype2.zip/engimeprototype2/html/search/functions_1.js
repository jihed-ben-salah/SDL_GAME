var searchData=
[
  ['initialiser',['initialiser',['../enigme_8c.html#a78ee5fe9ff1ac4e978db4f4678a73bd0',1,'initialiser(enigme_sf *E):&#160;enigme.c'],['../enigme_8h.html#a78ee5fe9ff1ac4e978db4f4678a73bd0',1,'initialiser(enigme_sf *E):&#160;enigme.c']]]
];
