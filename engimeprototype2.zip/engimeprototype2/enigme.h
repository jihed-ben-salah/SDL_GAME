
#ifndef ENIGME_H_
#define ENIGME_H_
/**  
* @struct enigme  * 
@brief struct for enigme */  
typedef struct enigme_sf 
{  
SDL_Surface *image[15];/*!< Surface. */
int pos_x[15];/*!< entier. */
int pos_y[15];/*!< entier. */
SDL_Rect pos[16];/*!< rectangle. */
}enigme_sf;

void initialiser (  enigme_sf * E);
void aleatoire ( enigme_sf *E);
void afficher(enigme_sf *E,  SDL_Surface *screen,int i);
int resolution ( enigme_sf E, SDL_Surface * screen, SDL_Event P,SDL_Surface *image,SDL_Rect positionbackground);
#endif

