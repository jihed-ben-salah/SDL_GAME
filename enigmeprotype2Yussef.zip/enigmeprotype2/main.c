#include<stdio.h>
#include"SDL/SDL.h"
#include "SDL/SDL_image.h"
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include "fonction.h"
int main(void)
{Enigme E;
char pause;
int i;


SDL_Surface *surface_enigme;
SDL_Event event;


// ouverture fenetre
    surface_enigme=SDL_SetVideoMode(710,710,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
    if(surface_enigme==NULL)
    {
        printf("Unable to set video mode : %s",SDL_GetError());
        return 1;
    } 

initialiser ("fichier.txt",E);

afficher(E,surface_enigme);
int done=0;
while (done)
{

while(SDL_PollEvent(&event))
        {
            if(event.type==SDL_QUIT)
            
                done=1 ;
               

            
              else 
              i=resolution (E,surface_enigme,event);
               
         
         }
}
pause=getchar();
SDL_Quit();
}
