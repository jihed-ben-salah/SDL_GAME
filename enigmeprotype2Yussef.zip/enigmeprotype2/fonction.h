#ifndef ENIGMEAVECFICHIER_H_
#define ENIGMEAVECFICHIER_H_

//soumaya enigme avec fichier
typedef struct {

char rep1[10];
SDL_Surface *r1;
SDL_Rect position_rep1;
char rep2[10];
SDL_Surface *r2;
SDL_Rect position_rep2;
char rep3[10];
SDL_Surface *r3;
SDL_Rect position_rep3;
char rep_vrai[10];
}rep; 

typedef struct { 
char question[150];
rep reponse;
SDL_Surface *ques;
SDL_Rect position_question;
}Enigme;



//soumaya enigme avec fichier 
int aleatoire ();//initialiser
void initialiser (char* fichier,Enigme E);
void afficher(Enigme E, SDL_Surface * surface_enigme);
int resolution (Enigme E, SDL_Surface *surface_enigme,SDL_Event event);


#endif
