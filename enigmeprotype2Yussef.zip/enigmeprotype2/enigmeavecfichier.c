#include <stdio.h>
#include "SDL/SDL.h"
#include <string.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include <time.h>
#include "fonction.h"


int aleatoire()
{int i;
do {
    srand(time(NULL));
   i=rand()%20;
     
  } while(i>8 );

return i;
}
void initialiser (char* fichier,Enigme E)
{
FILE *f=NULL;
int numero,i=0,j=0;

char caractereActuel;
char chaine[256]="";
numero=aleatoire();
printf("%d",numero);
f=fopen(fichier,"r");
if(f!=NULL)
{while(fgets(chaine,256,f)!=NULL)
{j++;

if(j==numero)
{caractereActuel = fgetc(f); 

 while(caractereActuel!='.')
               {E.question[i]=caractereActuel; 
                  i++;
                caractereActuel = fgetc(f); // On lit le caractère
                
               }
printf("%s",E.question);
            i=0;
caractereActuel = fgetc(f);
 while(caractereActuel!='.')
               {E.reponse.rep1[i]=caractereActuel; 
                i++;
                caractereActuel=fgetc(f); // On lit le caractère
                
               }
printf("%s",E.reponse.rep1);
i=0;
caractereActuel = fgetc(f);
while(caractereActuel!='.')
               {E.reponse.rep2[i]=caractereActuel; 
                 i++;
                 caractereActuel=fgetc(f); // On lit le caractère
               
               }
printf("%s",E.reponse.rep2);
           i=0;
caractereActuel = fgetc(f);
while(caractereActuel!='.')
               {E.reponse.rep3[i]=caractereActuel; 
                 i++;
                 caractereActuel=fgetc(f); // On lit le caractère
                
               }
printf("%s",E.reponse.rep3);
        i=0;
caractereActuel = fgetc(f);
while(caractereActuel!='.')
               {E.reponse.rep_vrai[i]=caractereActuel; 
                  i++;
                   caractereActuel=fgetc(f); // On lit le caractère
              
               }

}

}
fclose(f);


}


}

void afficher(Enigme E, SDL_Surface * surface_enigme)
{
TTF_Font *police = NULL;

SDL_Rect positionfonds;
SDL_Surface *fonds;
SDL_Color couleurNoire = {0,0,0};
    TTF_Init();
    police = TTF_OpenFont("Sketch.ttf",35);


     //fonds de l'enigme
     fonds=IMG_Load("fonds.png");
     positionfonds.x=0;
     positionfonds.y=0;

    // Écriture du texte dans la SDL_Surface question
    E.ques=TTF_RenderText_Blended(police,E.question, couleurNoire);
     E.position_question.x = 100;
     E.position_question.y = 100;


// Écriture du texte dans la SDL_Surface reponse1

    E.reponse.r1=TTF_RenderText_Blended(police,E.reponse.rep1, couleurNoire);
     E.reponse.position_rep1.x = 200;
    E.reponse.position_rep1.y =200 ;
// Écriture du texte dans la SDL_Surface reponse2
    E.reponse.r2=TTF_RenderText_Blended(police,E.reponse.rep2, couleurNoire);
     E.reponse.position_rep2.x = 200;
     E.reponse.position_rep2.y =300 ;
// Écriture du texte dans la SDL_Surface reponse3
    E.reponse.r3=TTF_RenderText_Blended(police,E.reponse.rep3, couleurNoire);
     E.reponse.position_rep3.x = 200;
     E.reponse.position_rep3.y =400 ;
//blit

    SDL_BlitSurface(fonds, NULL,surface_enigme,&positionfonds);
    SDL_BlitSurface(E.ques, NULL,surface_enigme,&E.position_question);
    SDL_BlitSurface(E.reponse.r1, NULL,surface_enigme,&E.reponse.position_rep1);
    SDL_BlitSurface(E.reponse.r2, NULL,surface_enigme,&E.reponse.position_rep2);
    SDL_BlitSurface(E.reponse.r3,NULL,surface_enigme,&E.reponse.position_rep3);
 SDL_Flip(surface_enigme);

    TTF_CloseFont(police);
    TTF_Quit();
  
   
}


int resolution (Enigme E, SDL_Surface *surface_enigme,SDL_Event event)
{afficher(E,surface_enigme);


int a,b;
 a=event.button.x;
 b=event.button.y ;


int Reso;
if (a > E.reponse.position_rep1.x && a< E.reponse.position_rep1.x+E.reponse.position_rep1.w && b >E.reponse.position_rep1.y && b < E.reponse.position_rep1.y+E.reponse.position_rep1.h )
    {if(strcmp(E.reponse.rep1,E.reponse.rep_vrai)==0)
      Reso=1;
    else
     Reso=0;


     }
if (a > E.reponse.position_rep2.x && a< E.reponse.position_rep2.x+E.reponse.position_rep2.w && b >E.reponse.position_rep2.y && b < E.reponse.position_rep2.y+E.reponse.position_rep2.h )
    {if(strcmp(E.reponse.rep2,E.reponse.rep_vrai)==0)
      Reso=1;
    else
     Reso=0;


     }
if (a > E.reponse.position_rep3.x && a< E.reponse.position_rep3.x+E.reponse.position_rep3.w && b >E.reponse.position_rep3.y && b < E.reponse.position_rep3.y+E.reponse.position_rep3.h )
    {if(strcmp(E.reponse.rep1,E.reponse.rep_vrai)==0)
      Reso=1;
    else
     Reso=0;


     }
 
return Reso;
}

